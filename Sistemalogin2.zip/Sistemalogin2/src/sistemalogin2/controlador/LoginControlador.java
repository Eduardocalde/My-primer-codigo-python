package sistemalogin2.controlador;

import sistemalogin2.modelo.Usuario;
import sistemalogin2.modelo.UsuarioDAO;
import sistemalogin2.vista.LoginVista;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginControlador {
    
    private LoginVista vista;
    private UsuarioDAO dao;
    
    public LoginControlador(LoginVista vista, UsuarioDAO dao) {
        this.vista = vista;
        this.dao = dao;
        conectarEventos();
    }
    
    private void conectarEventos() {
        this.vista.getBtnIngresar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                procesarLogin();
            }
        });
    }
    
    public void procesarLogin() {
        String username = vista.getTxtUsuario().getText();
        String password = new String(vista.getTxtContrasena().getPassword());
        
        if (username.isEmpty() || password.isEmpty()) {
            vista.mostrarMensajeError("Por favor, ingrese usuario y contraseña");
            return;
        }
        
        Usuario usuario = dao.validarUsuario(username, password);
        
        if (usuario != null) {
            vista.mostrarMensajeExito("Bienvenido " + usuario.getUsername());
            vista.setVisible(false);
            usuario.mostrarMenu();
        } else {
            vista.mostrarMensajeError("Usuario o contraseña incorrectos");
        }
    }
}