package sistemalogin2.modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {
    
    // Datos de conexión a MySQL
    private static final String URL = "jdbc:mysql://localhost:3306/sistema_login";
    private static final String USER = "root";
    private static final String PASSWORD = "Root2025"; // Tu contraseña de MySQL
    
    public static Connection getConexion() {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            System.out.println("Error de conexión: " + e.getMessage());
            return null;
        }
    }
}
