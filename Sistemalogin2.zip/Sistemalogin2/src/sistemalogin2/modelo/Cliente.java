package sistemalogin2.modelo;

public class Cliente extends Usuario {
    
    public Cliente(int id, String username, String password) {
        super(id, username, password, "cliente");
    }
    
    @Override
    public void mostrarMenu() {
        System.out.println("Menú de Cliente - Bienvenido " + username);
    }
}