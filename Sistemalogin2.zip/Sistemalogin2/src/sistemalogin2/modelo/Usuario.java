package sistemalogin2.modelo;

public abstract class Usuario {
    
    // Atributos
    protected int id;
    protected String username;
    protected String password;
    protected String rol;
    
    // Constructor
    public Usuario(int id, String username, String password, String rol) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.rol = rol;
    }
    
    // Método abstracto para el polimorfismo
    public abstract void mostrarMenu();
    
    // Métodos para obtener los datos
    public int getId() { return id; }
    public String getUsername() { return username; }
    public String getRol() { return rol; }
}
