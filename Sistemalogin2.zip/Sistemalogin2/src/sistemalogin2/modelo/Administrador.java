package sistemalogin2.modelo;

public class Administrador extends Usuario {
    
    private String area;
    
    public Administrador(int id, String username, String password, String areaAdmin) {
        super(id, username, password, "administrador");
        this.area = areaAdmin;
    }
    
    @Override
    public void mostrarMenu() {
        System.out.println("Menú de Administrador - Área: " + area);
    }
    
    public String getArea() { return area; }
}