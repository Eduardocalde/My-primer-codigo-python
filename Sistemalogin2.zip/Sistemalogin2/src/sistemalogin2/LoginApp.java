package sistemalogin2;

import sistemalogin2.controlador.LoginControlador;
import sistemalogin2.modelo.UsuarioDAO;
import sistemalogin2.vista.LoginVista;

public class LoginApp {
    public static void main(String[] args) {
        LoginVista vista = new LoginVista();
        UsuarioDAO dao = new UsuarioDAO();
        new LoginControlador(vista, dao);
        vista.setVisible(true);
    }
}