package sistemalogin2.vista;

import javax.swing.*;

public class MenuAdminVista extends JFrame {
    public MenuAdminVista() {
        setTitle("Panel de Administrador");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        add(new JLabel("Bienvenido, Administrador", SwingConstants.CENTER));
    }
}
