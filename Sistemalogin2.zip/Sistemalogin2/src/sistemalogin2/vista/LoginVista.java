package sistemalogin2.vista;

import javax.swing.*;
import java.awt.*;

public class LoginVista extends JFrame {
    
    private JTextField txtUsuario;
    private JPasswordField txtContrasena;
    private JButton btnIngresar;
    
    public LoginVista() {
        setTitle("SYNTAXIS PRO - Login");
        setSize(350, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(3, 2, 10, 10));
        
        add(new JLabel("  Usuario:"));
        txtUsuario = new JTextField();
        add(txtUsuario);
        
        add(new JLabel("  Contraseña:"));
        txtContrasena = new JPasswordField();
        add(txtContrasena);
        
        btnIngresar = new JButton("Iniciar Sesión");
        add(new JLabel(""));
        add(btnIngresar);
    }
    
    public JTextField getTxtUsuario() { return txtUsuario; }
    public JPasswordField getTxtContrasena() { return txtContrasena; }
    public JButton getBtnIngresar() { return btnIngresar; }
    
    public void mostrarMensajeExito(String msg) {
        JOptionPane.showMessageDialog(this, msg);
    }
    
    public void mostrarMensajeError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }
}
