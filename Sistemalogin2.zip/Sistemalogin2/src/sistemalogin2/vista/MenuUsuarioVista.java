package sistemalogin2.vista;

import javax.swing.*;

public class MenuUsuarioVista extends JFrame {
    public MenuUsuarioVista() {
        setTitle("Panel de Cliente");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        add(new JLabel("Bienvenido, Cliente", SwingConstants.CENTER));
    }
}