package servicio;

import modelo.Miembro;
import java.util.ArrayList;
import java.util.List;

public class AsignadorTurnos {
    
    private List<Miembro> miembros = new ArrayList<>();
    
    public void agregarMiembro(Miembro m) {
        miembros.add(m);
    }
    
    public void asignarServicio() {
        for (Miembro m : miembros) {
            m.realizarServicio();
        }
    }
    
    public void mostrarTodos() {
        System.out.println("=== MIEMBROS DEL MINISTERIO ===");
        for (Miembro m : miembros) {
            m.mostrarInfo();
            System.out.println("---");
        }
    }
}