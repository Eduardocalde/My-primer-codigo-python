package modelo;

public class Turno {
    
    private String dia;
    private String hora;
    private String rol;
    
    public Turno(String dia, String hora, String rol) {
        this.dia = dia;
        this.hora = hora;
        this.rol = rol;
    }
    
    public String getDia() { return dia; }
    public String getHora() { return hora; }
    public String getRol() { return rol; }
    
    public void cambiarRol(String nuevoRol) {
        if (nuevoRol != null && !nuevoRol.isEmpty()) {
            this.rol = nuevoRol;
            System.out.println("Rol cambiado a: " + nuevoRol);
        } else {
            System.out.println("Error: rol inválido");
        }
    }
    
    public void mostrarTurno() {
        System.out.println("Turno: " + dia + " | " + hora + " | " + rol);
    }
}