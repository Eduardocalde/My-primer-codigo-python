package modelo;

public abstract class Miembro {
    
    protected String nombre;
    protected String telefono;
    protected String rol;
    
    public Miembro(String nombre, String telefono, String rol) {
        this.nombre = nombre;
        this.telefono = telefono;
        this.rol = rol;
    }
    
    public abstract void realizarServicio();
    
    public void mostrarInfo() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Teléfono: " + telefono);
        System.out.println("Rol: " + rol);
    }
    
    public String getNombre() { return nombre; }
    public String getRol() { return rol; }
}
