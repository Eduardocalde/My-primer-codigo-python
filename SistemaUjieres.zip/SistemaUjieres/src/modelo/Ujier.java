package modelo;

public class Ujier extends Miembro {
    
    private int numeroTurno;
    
    public Ujier(String nombre, String telefono, int numeroTurno) {
        super(nombre, telefono, "Ujier");
        this.numeroTurno = numeroTurno;
    }
    
    @Override
    public void realizarServicio() {
        System.out.println(nombre + " está en la puerta recibiendo a los hermanos.");
    }
    
    public int getNumeroTurno() { return numeroTurno; }
}