package modelo;

public class Caballero extends Miembro {
    
    private String area;
    
    public Caballero(String nombre, String telefono, String area) {
        super(nombre, telefono, "Caballero");
        this.area = area;
    }
    
    @Override
    public void realizarServicio() {
        System.out.println(nombre + " está sirviendo en el área de " + area + ".");
    }
    
    public String getArea() { return area; }
}