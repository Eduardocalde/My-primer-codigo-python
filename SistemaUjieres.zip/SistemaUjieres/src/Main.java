import modelo.Ujier;
import modelo.Caballero;
import modelo.Turno;
import servicio.AsignadorTurnos;

public class Main {
    public static void main(String[] args) {
        
        System.out.println("=== SISTEMA DE GESTIÓN DE UJIERES ===\n");
        
        System.out.println("--- 1. ABSTRACCIÓN ---");
        System.out.println("No se puede instanciar 'Miembro' porque es abstracto.\n");
        
        System.out.println("--- 2. HERENCIA ---");
        Ujier ujier1 = new Ujier("Eduardo Calderón", "0424-1943415", 5);
        Ujier ujier2 = new Ujier("María Gómez", "0414-1234567", 3);
        Caballero caballero1 = new Caballero("José Pérez", "0412-9876543", "Estacionamiento");
        
        ujier1.mostrarInfo();
        System.out.println("---");
        caballero1.mostrarInfo();
        System.out.println();
        
        System.out.println("--- 3. ENCAPSULAMIENTO ---");
        Turno turno1 = new Turno("Domingo", "9:00 AM", "Puerta");
        turno1.mostrarTurno();
        turno1.cambiarRol("Agua");
        turno1.mostrarTurno();
        System.out.println();
        
        System.out.println("--- 4. POLIMORFISMO ---");
        AsignadorTurnos asignador = new AsignadorTurnos();
        asignador.agregarMiembro(ujier1);
        asignador.agregarMiembro(ujier2);
        asignador.agregarMiembro(caballero1);
        asignador.asignarServicio();
    }
}